<footer>
<div class="footer-con-container">
	<div class="footer-con-overlay darkmode-header">
		<div class="wavebar-con-container">
			<div class="wavebar-con-wrap">
			  <div class="wavebar-svg-object"></div>
			  <div class="wavebar-svg-object"></div>
			</div>
		</div>
		<div class="footer-con-header">
			<div class="footer-con-outer">
				<div class="footer-con-inner">
					
					<table class="footer-table-out">
					<tr>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<a href="https://vk.com/lesha_stepanenko" target="_blank">
										<span>Создатль идеи</span>
									</a>
									</div>
								
					
								</div>
							</div>
						</td>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<a href="https://vk.com/cuttelloverius" target="_blank">
										<span>Создатель графики</span>
									</a>
									</div>
									
								</div>
							</div>
						</td>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<a href="https://disk.yandex.ru/d/SipiKG-uRf0i0Q" target="_blank">
										<span>Скачать игру</span>
									</a>
									</div>
									
								</div>
							</div>
						</td>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<a href="https://vk.com/iddpika" target="_blank">
										<span>Создатель сайта</span>
									</a>
									</div>
								
								</div>
							</div>
						</td>
						
					</tr>
					</table>
				</div>
			</div>
		</div>
		
	</div>
</div>
</footer>